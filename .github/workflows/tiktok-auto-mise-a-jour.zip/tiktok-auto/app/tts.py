"""Voix off française naturelle avec Microsoft Edge TTS (gratuit, sans clé),
avec horodatage mot par mot pour des sous-titres synchronisés."""
import asyncio
import os
import re
import subprocess
from pathlib import Path

from . import config


def _probe_duration(path: Path) -> float:
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                          "-of", "default=nw=1:nk=1", str(path)],
                         capture_output=True, text=True, check=True).stdout
    return float(out.strip())


async def _edge(text: str, mp3: Path, voice: str) -> list[tuple[float, float, str]]:
    import edge_tts
    try:
        com = edge_tts.Communicate(text, voice, rate=config.VOICE_RATE, boundary="WordBoundary")
    except TypeError:  # anciennes versions
        com = edge_tts.Communicate(text, voice, rate=config.VOICE_RATE)
    words = []
    with open(mp3, "wb") as f:
        async for chunk in com.stream():
            if chunk["type"] == "audio":
                f.write(chunk["data"])
            elif chunk["type"] == "WordBoundary":
                s = chunk["offset"] / 1e7
                words.append((s, s + chunk["duration"] / 1e7, chunk["text"]))
    return words


PIPER_VOICES = {  # voix françaises Piper (gratuites, hors ligne) — secours si Edge est indisponible
    "default": "fr/fr_FR/tom/medium/fr_FR-tom-medium",
}
PIPER_PITCH = {"fr-FR-DeniseNeural": 1.12, "fr-FR-EloiseNeural": 1.18, "fr-FR-HenriNeural": 0.9}


def _piper(text: str, out: Path, voice: str):
    """Synthèse Piper puis léger changement de hauteur pour distinguer les personnages."""
    import urllib.request
    base = Path(os.getenv("PIPER_DIR", Path.home() / ".piper"))
    base.mkdir(parents=True, exist_ok=True)
    rel = PIPER_VOICES["default"]
    model = base / (rel.split("/")[-1] + ".onnx")
    for ext in (".onnx", ".onnx.json"):
        f = base / (rel.split("/")[-1] + ext)
        if not f.exists():
            urllib.request.urlretrieve(
                f"https://huggingface.co/rhasspy/piper-voices/resolve/main/{rel}{ext}", f)
    wav = out.with_suffix(".piper.wav")
    from piper import PiperVoice
    v = PiperVoice.load(str(model))
    import wave as _w
    with _w.open(str(wav), "wb") as wf:
        if hasattr(v, "synthesize_wav"):
            v.synthesize_wav(text, wf)
        else:
            v.synthesize(text, wf)
    k = PIPER_PITCH.get(voice, 1.0)
    af = f"asetrate=22050*{k},aresample=24000,atempo={1 / k:.4f}" if k != 1.0 else "aresample=24000"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(wav), "-af", af, "-q:a", "3", str(out)],
                   check=True)
    wav.unlink(missing_ok=True)


def _estimate_words(text: str, total: float) -> list[tuple[float, float, str]]:
    toks = text.split()
    weights = [max(len(re.sub(r"\W", "", t)), 2) for t in toks]
    scale = (total - 0.2) / sum(weights)
    t, out = 0.1, []
    for tok, w in zip(toks, weights):
        out.append((t, t + w * scale, tok))
        t += w * scale
    return out


def _silent(seconds: float, path: Path):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                    "anullsrc=r=24000:cl=mono", "-t", f"{seconds:.2f}", "-q:a", "4", str(path)],
                   check=True)


def _align_punctuation(text: str, words: list[tuple[float, float, str]]):
    """Edge renvoie les mots sans ponctuation : on réutilise les jetons du texte original
    (avec virgules, ?, €…) pour un affichage propre."""
    toks = text.split()
    if len(toks) == len(words):
        return [(s, e, tok) for (s, e, _), tok in zip(words, toks)]
    return words


def synthesize(scenes: list[dict], workdir: Path) -> list[dict]:
    """Ajoute à chaque scène : audio, duration, words (relatifs à la scène)."""
    workdir.mkdir(parents=True, exist_ok=True)
    for i, sc in enumerate(scenes):
        text = sc["narration"].strip()
        mp3 = workdir / f"voice_{i:02d}.mp3"
        words = None
        if not config.OFFLINE:
            try:
                words = asyncio.run(_edge(text, mp3, sc.get("voice") or config.VOICE))
            except Exception as e:
                print(f"[voix] Edge TTS indisponible ({e}), essai Piper")
                try:
                    _piper(text, mp3, sc.get("voice") or config.VOICE)
                    words = []
                except Exception as e2:
                    print(f"[voix] Piper indisponible ({e2}), voix muette de secours")
                    words = None
        if words is None:
            est = max(1.5, len(text.split()) / 2.7)
            _silent(est, mp3)
            words = []
        dur = _probe_duration(mp3)
        if not words:
            words = _estimate_words(text, dur)
        sc.update(audio=str(mp3), duration=dur + 0.15, words=_align_punctuation(text, words))
    return scenes
